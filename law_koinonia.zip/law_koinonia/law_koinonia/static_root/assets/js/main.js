const toggleButton = document.getElementsByClassName("toggle-button")[0];
const navbarMenu = document.getElementsByClassName("nav_menu")[0];
const navbarProfile = document.getElementsByClassName("nav_profile")[0];
toggleButton.addEventListener("click", () => {
  navbarMenu.classList.toggle("active");
  navbarProfile.classList.toggle("deactive");
});

// Searchbar Click

const searchButton = document.getElementsByClassName("search_bar")[0];
const searchBarInput = document.getElementsByClassName("search_bar_input")[0];
const searchBarInputBackArrow =
  document.getElementsByClassName("back_arrow")[0];
searchButton.addEventListener("click", () => {
  searchBarInput.classList.add("active");
  searchButton.classList.add("deactive");
  toggleButton.classList.add("deactive");
  navbarMenu.classList.remove("active");
  navbarProfile.classList.add("deactive");
});

searchBarInputBackArrow.addEventListener("click", () => {
  searchBarInput.classList.remove("active");
  searchButton.classList.remove("deactive");
  toggleButton.classList.remove("deactive");
  navbarProfile.classList.remove("deactive");
});

const navProfileDetails = document.getElementsByClassName(
  "nav_profile_details"
)[0];
const navProfileBox = document.getElementsByClassName("profile_box")[0];

navProfileDetails.addEventListener("click", () => {
  navProfileBox.classList.toggle("active");
  navProfileDetails.classList.toggle("active");
});

// Show More Box

const showMore = document.getElementsByClassName("show_more")[0];
const showLess = document.getElementsByClassName("show_less")[0];
const showDetails = document.getElementsByClassName("show_details")[0];

showMore.addEventListener("click", () => {
  showMore.classList.add("deactive");
  showDetails.classList.add("active");
  showLess.classList.add("active");
});
showLess.addEventListener("click", () => {
  showMore.classList.remove("deactive");
  showDetails.classList.remove("active");
  showLess.classList.remove("active");
});

// Post field Visible

const profilePostInput =
  document.getElementsByClassName("profile_post_input")[0];
const postingPage = document.getElementsByClassName("posting_page")[0];
const closePostingPage = document.getElementsByClassName(
  "posting_modal-close"
)[0];

profilePostInput.addEventListener("click", () => {
  postingPage.classList.add("active");
});

closePostingPage.addEventListener("click", () => {
  postingPage.classList.remove("active");
});
